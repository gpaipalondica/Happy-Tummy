#register user
{
    "username": "k$",
    "email" : "karan@ks.com",
    "first_name" : "karan",
    "last_name" : "sharma",
    "address" : "moon, besides the Earth",
    "city" : "ulhasnagar",
    "state" : "liquid",
    "zipcode" : "556969",
    "phone_number" : "5588662211",
    "password" : "visible",
    "password2" : "visible"
}

#user_order_details
{
    "user_order" : {
        "4" : {
            "order_id" : 4,
            "total_cost" : 75,
            "created_at" : "",
            "ingredients" : [
                {
                    "item_id" : 8,
                    "name" : "namak",
                    "unit" : "chutki",
                    "price" : 25,
                    "quantity" : 1
                },
                {
                    "item_id" : 8,
                    "name" : "namak",
                    "unit" : "chutki",
                    "price" : 25,
                    "quantity" : 1
                },
                {
                    "item_id" : 8,
                    "name" : "namak",
                    "unit" : "chutki",
                    "price" : 25,
                    "quantity" : 1
                }
            ]
        }        
    }
}
{
    'order_id': 1, 
    'items': [
        {
            'item_id': 1, 
            'quantity': 2
        }, 
        { 
            'item_id': 1, 
            'quantity': 2
        },
    ], 
    'user_id': 69,
}


    #order_id, item_id, quantity


{
"name": "karan",
"phone": "7219204736",
"email": "karan@sharma.com",
}

#Login
{
    "username": "admin",
    "password": "admin"
}


#Ingredients
{
    "order_id": 1,
    "item_id" : 1,
    "quantity" : 1,
}

#order
# Authorization: Token faf076e09c1a993172cde76d434342895462e86fb74a115fec830642d07da304
{
    "Ingredients" : [
        {
            "item_id": 20, 
            "quantity": 2
        }, 
        { 
            "item_id": 28, 
            "quantity": 1
        }
    ]
}


#One Recipe
{
    "name": "Homemade Pizza & Pizza Dough",
    "timeRequired": "60 mins",
    "url": "https://www.simplyrecipes.com/recipes/homemade_pizza/",
    "imageUrl": "https://www.simplyrecipes.com/thmb/2dz-J3ziFdbt1oMzbJAx0wVnlME=/390x260/filters:max_bytes(150000):strip_icc()/Simply-Recipes-Homemade-Pizza-Dough-Lead-Shot-1c-c2b1885d27d4481c9cfe6f6286a64342.jpg",
    "instructions": [
        {
            "heading": "Proof the yeast: ",
            "text": "\nPlace the warm water in the large bowl of a heavy duty stand mixer. Sprinkle the yeast over the warm water and let it sit for 5 minutes until the yeast is dissolved.\n\n\nAfter 5 minutes stir if the yeast hasn't dissolved completely. The yeast should begin to foam or bloom, indicating that the yeast is still active and alive.\n\n\n(Note that if you are using \"instant yeast\" instead of \"active yeast\", no proofing is required. Just add to the flour in the next step.)\n\n"
        },
        {
            "heading": " Make and knead the pizza dough: ",
            "text": "\nAdd the flour, salt, sugar, and olive oil, and using the mixing paddle attachment, mix on low speed for a minute. Then replace the mixing paddle with the dough hook attachment.\n\n\nKnead the pizza dough on low to medium speed using the dough hook about 7-10 minutes.\n\n\nIf you don't have a mixer, you can mix the ingredients together and knead them by hand.\n\n\nThe dough should be a little sticky, or tacky to the touch. If it's too wet, sprinkle in a little more flour.\n\n"
        },
        {
            "heading": " Let the dough rise: ",
            "text": "\nSpread a thin layer of olive oil over the inside of a large bowl. Place the pizza dough in the bowl and turn it around so that it gets coated with the oil.\n\n\nAt this point you can choose how long you want the dough to ferment and rise. A slow fermentation (24 hours in the fridge) will result in more complex flavors in the dough. A quick fermentation (1 1/2 hours in a warm place) will allow the dough to rise sufficiently to work with.\n\n\nCover the dough with plastic wrap.\n\n\nFor a quick rise, place the dough in a warm place (75°F to 85°F) for 1 1/2 hours.\n\n\nFor a medium rise, place the dough in a regular room temperature place (your kitchen counter will do fine) for 8 hours. For a longer rise, chill the dough in the refrigerator for 24 hours (no more than 48 hours).\n\n\nThe longer the rise (to a point) the better the flavor the crust will have.\n\n"
        }
    ],
    "ingredients": [
        {
            "quantity": "1 1/2 cups (355",
            "unit": "ml)",
            "name": "warm water (105°F-115°F)"
        },
        {
            "quantity": "1 package (2 1/4",
            "unit": "teaspoons)",
            "name": "active dry yeast"
        },
        {
            "quantity": "3 3/4 cups (490",
            "unit": "g)",
            "name": "bread flour"
        },
        {
            "quantity": "2",
            "unit": "tablespoons",
            "name": "extra virgin olive oil (omit if cooking pizza in a wood-fired pizza oven)"
        },
        {
            "quantity": "2",
            "unit": "teaspoons",
            "name": "salt"
        },
        {
            "quantity": "1",
            "unit": "teaspoon",
            "name": "sugar"
        }
    ],
    #TEST
    # "test": [
    #     {
    #     "test_id" : "500"
    #     "test_quantity" : "50.50"
    #     }
    # ]
},