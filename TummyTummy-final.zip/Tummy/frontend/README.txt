1) Open folder on VS Code

2) Open Terminal using Ctrl and ` and run the command
   npm install react-scripts --save

3) Upon seeing node modules folder, run the command
   npm start