1) Open folder on VS Code

2) Open Terminal using Ctrl and ` in the frontend folder and run the command
   npm i

3) Upon seeing node modules folder, run the command
   npm start