import React from 'react'

export default function Form(props) {
    return (
        <div>
            <h1>Ajay</h1>
        </div>
    )
}
